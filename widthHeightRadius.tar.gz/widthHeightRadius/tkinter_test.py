import PIL
import Tkinter
import cv2
# import the necessary packages
from Tkinter import *
from PIL import Image
from PIL import ImageTk
import tkFileDialog
import cv2

import ttk
from ttk import *
import numpy as np
from matplotlib import pyplot as plt
#from common import Sketcher
import argparse
from scipy.spatial import distance as dist
from imutils import perspective
from imutils import contours
import imutils

###############################
#################################
#https://www.pyimagesearch.com/2016/03/28/measuring-size-of-objects-in-an-image-with-opencv/
def midpoint(ptA, ptB):
	return ((ptA[0] + ptB[0]) * 0.5, (ptA[1] + ptB[1]) * 0.5)
#################################
# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()

 
def select_image():
	# grab a reference to the image panels
	global panelA, panelB
 
	# open a file chooser dialog and allow the user to select an input
	# image
	path = tkFileDialog.askopenfilename()

	# ensure a file path was selected
	if len(path) > 0:
		# load the image from disk, convert it to grayscale, and detect
		# edges in it
		image = cv2.imread(path)
		#giving original size of image
		print('Original Dimensions : ',image.shape) 
		#resize an image for 100 width(cols), and 50 rows(height),(1249, 391)
		image = cv2.resize(image, (1240, 350)) 

		##############################################################
		# get dimensions of image
		dimensions = image.shape
		 
		# height, width, number of channels in image
		height = image.shape[0]
		width = image.shape[1]
		channels = image.shape[2]

		h, w = image.shape[:2]

		heightnp = np.size(image, 0)
		widthnp = np.size(image, 1)

		print('Original Dimensions : ',image.shape)  
		print('Image Dimension      : ',dimensions)
		print('Image Height(Raws)   : ',height)
		print('Image Width(columns) : ',width)
		print('Number of Channels   : ',channels)
		print('h   : ',h)
		print('w   : ',w)
		print('heightNP   : ',heightnp)
		print('widthNP   : ',widthnp)
		##############################################################
		#pixels iterating through image
		###############################################################
		###############################################################
		#px=image.shape[2]
		#col={}
		#for y in range(heightnp):
		#    for x in range(widthnp):
		#	c=px[x,y]
		#	col[c]=col.get(c,0)+1

		#print('c     : ',c)
		#print('col   : ',col)

		###############################################################		
		###############################################################

		cv2.imwrite("noisy_leaf.png", image)
		#cv2.imshow("noisy_leaf.jpeg", image)
		#####################################################
		#starting Clustering
		Z = image.reshape((-1,3))
		# convert to np.float32
		Z = np.float32(Z)
		# define criteria, number of clusters(K) and apply kmeans()
		criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
		K = 3
		ret,label,center=cv2.kmeans(Z,K,criteria,10,cv2.KMEANS_RANDOM_CENTERS)
			
		#label,center=cv2.kmeans(Z,K,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)
		# Now convert back into uint8, and make original image
		center = np.uint8(center)
		res = center[label.flatten()]
		res2 = res.reshape((image.shape))
		#cv2.imshow('Clustering Mean',res2)
		cv2.imwrite("Clustering_Mean.png", res2)
		ClusteredImg = cv2.imread('Clustering_Mean.png');
		print('cluster numbers      : ',K)
		###########################################end clustering

		hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
		b,g,r = cv2.split(image)
		rgb_img = cv2.merge([r,g,b])


		#gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
		gray = cv2.cvtColor(ClusteredImg,cv2.COLOR_BGR2GRAY)
		#dilation for the clusteredImage
		kernel = np.ones((2,2),np.uint8)
		gray= cv2.dilate(gray,kernel,iterations = 3)
		ret, thresh = cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

		##########################################################################################
		##########################################################################################

		# noise removal
		#kernel = np.ones((2,2),np.uint8)
		opening = cv2.morphologyEx(thresh,cv2.MORPH_OPEN,kernel, iterations = 4)
		#closing = cv2.morphologyEx(thresh,cv2.MORPH_CLOSE,kernel, iterations = 2)

		# sure background area
		sure_bg = cv2.dilate(opening,kernel,iterations=5)

		# Finding sure foreground area
		#dist_transform = cv2.distanceTransform(sure_bg,cv2.DIST_L2,3)
		# Threshold
		#ret, sure_fg = cv2.threshold(dist_transform,0.1*dist_transform.max(),255,0)

		#
		median = cv2.medianBlur(opening,5)
		dilation = cv2.dilate(median,kernel,iterations = 5)
		cv2.imwrite("dilation-Median-opening.png", dilation)

		# Read image
		im_in = cv2.imread("dilation-Median-opening.png" , cv2.IMREAD_GRAYSCALE);
		# Threshold.
		# Set values equal to or above 220 to 0.
		# Set values below 220 to 255.
		th, im_th = cv2.threshold(im_in, 220, 255, cv2.THRESH_BINARY_INV);
		# Copy the thresholded image.
		im_floodfill = im_th.copy()
		# Mask used to flood filling.
		# Notice the size needs to be 2 pixels than the image.
		h, w = im_th.shape[:2]
		mask = np.zeros((h+2, w+2), np.uint8)
		# Floodfill from point (0, 0)
		cv2.floodFill(im_floodfill, mask, (0,0), 255);
		# Invert floodfilled image
		im_floodfill_inv = cv2.bitwise_not(im_floodfill)
		# Combine the two images to get the foreground.
		im_out = im_th | im_floodfill_inv

		# Finding unknown region
		im_out = np.uint8(im_out)
		unknown = cv2.subtract(sure_bg,im_out)

		im_in= cv2.dilate(im_in,kernel,iterations = 6)
		#cv2.imshow("Gray-Image", im_in)
		cv2.imwrite("Gray-Image.png", im_in)


		# Display images.
		im_th= cv2.erode(im_th,kernel,iterations = 1)
		im_th=cv2.dilate(im_th,kernel,iterations = 8)
		#cv2.imshow("Thresholded Image", im_th)
		cv2.imwrite("Thresholded-Image.png", im_th)
		img6 = cv2.imread('Thresholded-Image.png');

		#background
		im_floodfill= cv2.dilate(im_floodfill,kernel,iterations = 6)
		#cv2.imshow("Floodfilled-Image", im_floodfill)
		cv2.imwrite("Floodfilled-Image.png", im_floodfill)
		img4 = cv2.imread('Floodfilled-Image.png');

		#coloring background
		img4[np.where((img4 == [0,0,0]).all(axis = 2))] = [255,0,255]
		img4= cv2.dilate(img4,kernel,iterations = 6)
		cv2.imwrite("Floodfilled-Image-Purple.png", img4)
		#cv2.imshow("Floodfilled-Image-Purple", img4)

		im_floodfill_inv= cv2.dilate(im_floodfill_inv,kernel,iterations = 6)
		#cv2.imshow("Inverted Floodfilled Image", im_floodfill_inv)
		cv2.imwrite("Inverted-Floodfilled-Image.png", im_floodfill_inv)
		img3 = cv2.imread('Inverted-Floodfilled-Image.png');

		#imgInv3 = cv2.dilate(img3,kernel,iterations = 6)
		#cv2.imshow("Inverted Floodfilled-Image-dilate", imgInv3)
		#cv2.imwrite("Inverted-Floodfilled-Image-dilate.png", imgInv3)

		
		#Foreground
		im_out= cv2.dilate(im_out,kernel,iterations = 10)
		#cv2.imshow("Foreground", im_out)
		cv2.imwrite("Foreground.png", im_out)
		img5 = cv2.imread('Foreground.png');


		#coloring Foreground
		img5[np.where((img5 == [0,0,0]).all(axis = 2))] = [255,255,0166]
		cv2.imwrite("ForegroundNew.png", img5)
		#cv2.imshow("ForegroundNew.png", img5)
		img55 = cv2.imread('ForegroundNew.png');


                ##################################
		########### the second frame
		################I added another edge for canny
		#edged = cv2.Canny(im_th, 50, 100)
 		edges2 = cv2.Canny(im_th,25,255,L2gradient=False)

		dilationCanny = cv2.dilate(edges2,kernel,iterations =5)
		#cv2.imshow('CannyOtsu',dilationCanny)
		cv2.imwrite("CannyOtsu.png", dilationCanny)
		edged = cv2.imread('CannyOtsu.png');
		####################################################################
		####################################################################
		
		#adding some logical operations here
		#weighted original + Canny
		weighted=cv2.addWeighted(image,0.6,edged,1.0,0)
		#cv2.imshow('weighted(original + Canny)',weighted)
		cv2.imwrite("weighted(original + Canny).png", weighted)

		#weighted2 (original + Canny)+Inverted Floodfilled Image
		weighted2=cv2.addWeighted(weighted,0.9,img3,0.6,0)
		#cv2.imshow('weighted2(original + Canny)+Inverted Floodfilled Image',weighted2)
		cv2.imwrite("weighted2(original + Canny)+Inverted Floodfilled Image.png", weighted2)

		#weighted3(original + Canny)+Inverted Floodfilled Image)+Floodfilled Image
		weighted3=cv2.addWeighted(weighted2,0.9,img4,0.3,0)
		#cv2.imshow('weighted3(original + Canny)+Inverted Floodfilled Image)+Floodfilled Image',weighted3)
		cv2.imwrite("weighted3(original + Canny)+Inverted Floodfilled Image)+Floodfilled Image.png", weighted3)

		#weighted4 / (original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground
		weighted4=cv2.addWeighted(weighted3,0.9,img55,0.4,0)
		#cv2.imshow('weighted4 (original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground',weighted4)
		cv2.imwrite("weighted4 (original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground.png", weighted4)


		#weighted5 / (original + Canny)+Inverted Floodfilled Image)+/ (original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground
		weighted5=cv2.addWeighted(weighted2,0.9,weighted4,0.3,0)
		#cv2.imshow('weighted5(original + Canny)+Inverted Floodfilled Image)+(original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground',weighted5)
		cv2.imwrite("weighted5(original + Canny)+Inverted Floodfilled Image)+(original + Canny)+Inverted Floodfilled Image)+Floodfilled Image)+Foreground.png", weighted5)

		#weighted6  (original + Canny)+Inverted Floodfilled Imag/+  /Thresholded-Image
		weighted6=cv2.addWeighted(weighted2,0.7,img6,0.6,0)
		#cv2.imshow('weighted6 (original + Canny)+Inverted Floodfilled Imag+Thresholded-Image',weighted6)
		cv2.imwrite("weighted6(original + Canny)+Inverted Floodfilled Imag+Thresholded-Image.png", weighted6)
		

		####################################################################
		####################################################################


		# find contours in the edge map
		cnts = cv2.findContours(dilationCanny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

		cnts = cnts[0] if imutils.is_cv2() else cnts[1]
		 
		# sort the contours from left-to-right and initialize the
		# 'pixels per metric' calibration variable
		(cnts, _) = contours.sort_contours(cnts)
		pixelsPerMetric = None
		#x = int(input("Enter the approximated diameter: "))
		# loop over the contours individually
		for c in cnts:
			# if the contour is not sufficiently large, 
			if  cv2.contourArea(c) > 4000:#x*1:
			        print('contourArea1       : ',cv2.contourArea(c))
				cv2.drawContours(edged,[c],0,(0,255,255),7)
				cv2.drawContours(mask,[c],0,255,-1)	
				#continue
			#ignoring for purple colors
		        if  cv2.contourArea(c) < 4000:#x*1:
			        print('contourArea11       : ',cv2.contourArea(c))
				cv2.drawContours(edged,[c],0,(255,0,255),7)
				cv2.drawContours(mask,[c],0,255,-1)	
				continue

		                print('contourArea2       : ',cv2.contourArea(c))
			#draw the box		
			if  cv2.contourArea(c) < 4000:#x*1:
				continue

			# compute the rotated bounding box of the contour
			orig = edged.copy()
			box = cv2.minAreaRect(c)
			box = cv2.cv.BoxPoints(box) if imutils.is_cv2() else cv2.boxPoints(box)
			box = np.array(box, dtype="int")
		 
			# order the points in the contour such that they appear
			# in top-left, top-right, bottom-right, and bottom-left
			# order, then draw the outline of the rotated bounding
			# box
			box = perspective.order_points(box)
			cv2.drawContours(orig, [box.astype("int")], -1, (0, 255, 0), 2)
		 
			# loop over the original points and draw them
			for (x, y) in box:
				cv2.circle(orig, (int(x), int(y)), 5, (0, 0, 255), -1)

		# unpack the ordered bounding box, then compute the midpoint
			# between the top-left and top-right coordinates, followed by
			# the midpoint between bottom-left and bottom-right coordinates
		(tl, tr, br, bl) = box
		(tltrX, tltrY) = midpoint(tl, tr)
		(blbrX, blbrY) = midpoint(bl, br)
		 
		# compute the midpoint between the top-left and top-right points,
		# followed by the midpoint between the top-righ and bottom-right
		(tlblX, tlblY) = midpoint(tl, bl)
		(trbrX, trbrY) = midpoint(tr, br)
		 
		# draw the midpoints on the image
		cv2.circle(orig, (int(tltrX), int(tltrY)), 5, (255, 0, 0), -1)
		cv2.circle(orig, (int(blbrX), int(blbrY)), 5, (255, 0, 0), -1)
		cv2.circle(orig, (int(tlblX), int(tlblY)), 5, (255, 0, 0), -1)
		cv2.circle(orig, (int(trbrX), int(trbrY)), 5, (255, 0, 0), -1)
		 
		# draw lines between the midpoints
		cv2.line(orig, (int(tltrX), int(tltrY)), (int(blbrX), int(blbrY)), (255, 0, 255), 4)
		cv2.line(orig, (int(tlblX), int(tlblY)), (int(trbrX), int(trbrY)), (255, 0, 255), 4)
		##################################

		# compute the Euclidean distance between the midpoints
		dA = dist.euclidean((tltrX, tltrY), (blbrX, blbrY))
		dB = dist.euclidean((tlblX, tlblY), (trbrX, trbrY))
		# if the pixels per metric has not been initialized, then
		# compute it as the ratio of pixels to supplied metric
		# (in this case, inches)
		#import argparse
		#parser = argparse.ArgumentParser()
		#parser.parse_args()
		#args = parser.parse_args()

		
		if pixelsPerMetric is None:
		    pixelsPerMetric = dB / orig.size #args["width"]
		#######################################
		# compute the size of the object
		dimA = dA / pixelsPerMetric
		dimB = dB / pixelsPerMetric

		# draw the object sizes on the image
		cv2.putText(orig, "{:.1f}in".format(dimA),(int(tltrX - 15), int(tltrY - 10)), cv2.FONT_HERSHEY_SIMPLEX,0.65, (255, 255, 255), 2)
		cv2.putText(orig, "{:.1f}in".format(dimB),(int(trbrX + 10), int(trbrY)), cv2.FONT_HERSHEY_SIMPLEX,0.65, (255, 255, 255), 2)


		###############################################
		#weighted=cv2.addWeighted(box,0.6,imgCanny2,1.0,0)
		#cv2.imshow('contourArea',orig)
		cv2.imwrite("contourArea.png", orig)

		##################################

		##################################

		#weighted7=cv2.addWeighted(box,0.6,imgCanny2,1.0,0)
		weighted7=cv2.addWeighted(orig,0.6,weighted3,0.8,0)
		#cv2.imshow('OrigWeighted3',weighted7)
		cv2.imwrite("OrigWeighted3.png", weighted7)

		################################################
		#First you draw the contour on both the sides of the border.
		#contour_id = 0
		#border_thickness = 10
		#border_color = (185, 115, 72)
		#conto=cv2.drawContours(weighted7, contours, contour_id, border_color, border_thickness)
                #cv2.imwrite("conto.png", conto)
		##################################
		# finds all of the white pixel coordinates in the image and places them in a list.
		white_coords = np.argwhere(weighted7 == 255) 
		print('white_coords   : ',white_coords)
		cv2.imwrite("white_coords.png", white_coords)
		# this is where I'm stuck!

		##################################
		# OpenCV represents images in BGR order; however PIL represents
		# images in RGB order, so we need to swap the channels
		image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
 
		# convert the images to PIL format...
		image = Image.fromarray(image)
		weighted7 = Image.fromarray(weighted7)
 
		# ...and then to ImageTk format
		image = ImageTk.PhotoImage(image)
		weighted7 = ImageTk.PhotoImage(weighted7)

		# if the panels are None, initialize them
		if panelA is None or panelB is None:
			# the first panel will store our original image
			panelA = Label(image=image)
			panelA.image = image
			panelA.pack(side="top", padx=1, pady=1)
 
			# while the second panel will store the edge map
			panelB = Label(image=weighted7)
			panelB.image = weighted7
			panelB.pack(side="bottom", padx=1, pady=1)
 
		# otherwise, update the image panels
		else:
			# update the pannels
			panelA.configure(image=image)
			panelB.configure(image=weighted7)
			panelA.image = image
			panelB.image = weighted7
'''
	        # loop over the image, pixel by pixel
	        for y in range(0, heightnp):
		   for x in range(0, widthnp):
		     # threshold the pixel
		      print('the image pixels are : ',image[y, x])
'''
'''
		def find_nearest_white(image, target):
		    nonzero = np.argwhere(image == 255)
		    distances = np.sqrt((nonzero[:,0] - TARGET[0]) ** 2 + (nonzero[:,1] - TARGET[1]) ** 2)
		    nearest_index = np.argmin(distances)
		    return nonzero[nearest_index]
		print('find_nearest_white   : ',find_nearest_white(image,255))
'''

# initialize the window toolkit along with the two image panels
root = Tk()
panelA = None
panelB = None
 
# create a button, then when pressed, will trigger a file chooser
# dialog and allow the user to select an input image; then add the
# button the GUI
btn = Button(root, text="Select an image", command=select_image)
btn.pack(side="bottom", fill="both", expand="yes", padx="10", pady="10")
 
# kick off the GUI
root.mainloop()
